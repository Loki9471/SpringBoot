package com.codegnan.curdrest.restController;

public class RestController {
	

}
