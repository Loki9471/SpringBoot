package com.codegnan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithRest01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
