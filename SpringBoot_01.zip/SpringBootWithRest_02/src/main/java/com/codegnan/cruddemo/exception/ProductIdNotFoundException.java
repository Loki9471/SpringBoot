package com.codegnan.cruddemo.exception;

public class ProductIdNotFoundException extends Exception {

}
