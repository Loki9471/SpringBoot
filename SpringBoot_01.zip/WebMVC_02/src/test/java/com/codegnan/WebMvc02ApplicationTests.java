package com.codegnan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebMvc02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
