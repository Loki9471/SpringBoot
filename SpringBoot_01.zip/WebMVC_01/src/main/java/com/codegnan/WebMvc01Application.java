package com.codegnan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebMvc01Application {

	public static void main(String[] args) {
		SpringApplication.run(WebMvc01Application.class, args);
	}

}
